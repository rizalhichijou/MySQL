<!DOCTYPE html>
<html>
<head>
	<title>Data siswa</title>
</head>
<body>
	<a href='in.php'>Kembali</a>
	<table border="1" width="80%">
<tr>
<th>No absen</th><th>Nama</th> <th>Umur</th> <th>Sekolah</th> <th>Option</th>
</tr>
</body>
</html>
<?php
include("connect.php");
$sql = "SELECT * FROM data_siswa";
$query = mysqli_query($db, $sql);

 while($siswa = mysqli_fetch_array($query)){
            echo "<tr>";

            echo "<td>".$siswa['id']."</td>";
            echo "<td>".$siswa['nama']."</td>";
            echo "<td>".$siswa['umur']."</td>";
            echo "<td>".$siswa['sekolah']."</td>";
  echo "<td><a href='edit.php?id=$siswa[id]'>Edit</a> | <a href='del.php?id=$siswa[id]'>Delete</a></td></tr>"; 
    
            echo "</tr>";
        }

?>
</table>
</html>