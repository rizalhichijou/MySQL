<?php
 $server = 'localhost';
 $database = 'roothost';
 $user = 'rizalsolehudin';
 $password = '';
 $db = mysqli_connect($server,$user,$password,$database);
 if(!$db){
 	die("Tidak bisa menghubungkan kedalam database : ".msqli_connect_erro());
 }

 	?>