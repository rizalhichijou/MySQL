<!DOCTYPE html>
<html>
<head>
	<title>Form data siswa</title>
</head>
<body>
<center>
	<form method='post' action='proses.php'>
		<fieldset>
			No Absen : <input type='text' name='absen'/><br/>
			Nama : <input type='text' name='nama'/><br/>
			Umur : <input type='text' name='umur'/><br/>
			Sekolah : <input type='text' name='sekolah'/><br/>
			Kirim : <input type='submit' name='simpan'/>
		</fieldset>
	</form>
	<fieldset>
		<li><a href='lihat.php'>Lihat data siswa</a></li>
	</fieldset>
</center>
</body>
</html>