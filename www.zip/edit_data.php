<?php
include("connect.php");

if(isset($_POST['siap'])){
	$id = $_POST['id'];
	$nama = $_POST['nama'];
	$umur = $_POST['umur'];
	$sekolah = $_POST['sekolah'];
	$query = "UPDATE data_siswa SET nama='$nama', umur='$umur', sekolah='$sekolah' WHERE id=$id";
	$sql = mysqli_query($db, $query);
	if($sql){
		header("Location: lihat.php");
	}else{
		die("Tidak dapat mengubah data");
	}
}

?>