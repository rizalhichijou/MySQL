<?php
include("connect.php");

if(isset($_GET['id'])){
	$id=$_GET['id'];
	$query = "DELETE FROM data_siswa WHERE id=$id";
	$execute = mysqli_query($db,$query);
	if($execute){
		header("Location: in.php");
	}else{
		die("Tidak bisa menghapus data");
	}
}else{
	die("Akses dilarang ");
}