<?php
error_reporting(0);
include 'connect.php';
if(isset($_POST["simpan"])){
	$id = $_POST['absen'];
	$nama = $_POST['nama'];
	$umur = $_POST['umur'];
	$sekolah = $_POST['sekolah'];
	if(!$id or !$nama or !$umur or !$sekolah){
		echo "<script type='text/javascript'>alert('jangan biarkan kosong');</script>";
		header("Location: masuk.php");
	}else{


	$query = "INSERT INTO data_siswa (id,nama,umur,sekolah) VALUE ('$id','$nama','$umur','$sekolah')";
	$sql = mysqli_query($db,$query);
	if($sql){
		header("Location: in.php");
	}else{
		header("Location: masuk.php?status=error");
		die("Data gagal disimpan");
	}
}
}
?>