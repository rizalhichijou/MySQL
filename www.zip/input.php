<?php

include( "connect.php");
if(isset($_POST['data'])){
	$nama_siswa=$_POST['nama'];
	$kelakuan = $_POST['kelakuan'];
	$no_absen = $_POST["absen"];
	$pelajaran = $_POST['pelajaran'];
	$perintah = "INSERT INTO `data_siswa` (`no_absen`, `nama_siswa`, `kelakuan_siswa`, `pelajaran`) VALUES ('$no_absen', '$nama_siswa', '$kelakuan', '$pelajaran')";
	$sql = mysqli_query($db,$perintah);
	if($sql){
		header("Location: input.php?success=true");
	}else{
		die('Gagal menyimpan data : '.mysqli_connect_error());
	}
}

?>