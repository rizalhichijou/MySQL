<?php 
include("connect.php");
// kalau tidak ada id di query string
if( !isset($_GET['id']) ){
    header('Location: lihat.php');
}

//ambil id dari query string
$id = $_GET['id'];

// buat query untuk ambil data dari database
$sql = "SELECT * FROM data_siswa WHERE id=$id";
$query = mysqli_query($db, $sql);
$siswa = mysqli_fetch_assoc($query);

// jika data yang di-edit tidak ditemukan
if( mysqli_num_rows($query) < 1 ){
    die("data tidak ditemukan...");
}


?>
<!DOCTYPE html>
<html>
<head>
	<title>Edit data siswa</title>
</head>
<body>
<center><fieldset>
	<form method='post' action='edit_data.php'>
	<input type='hidden' name='id' value='<?php echo $siswa["id"];?>'/> 
	Nama : <input type='text' name='nama'/><br/>
	Umur : <input type='text' name='umur'/><br/>
	Sekolah : <input type='text' name='sekolah'/>
	<input type='submit' name='siap' value='simpan'/>
</form>
</fieldset></center>
</body>
</html>